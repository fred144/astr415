#!/bin/bash 

# here do the part 1 
echo "Doing Problem 1"
./p1_pset4 

echo "Doing Problem 2"
./p2_pset4 

echo "making plots"
python3 ./plot.py